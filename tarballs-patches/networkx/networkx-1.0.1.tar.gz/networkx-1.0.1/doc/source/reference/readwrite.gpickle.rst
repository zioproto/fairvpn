Pickle
======
.. automodule:: networkx.readwrite.gpickle
.. currentmodule:: networkx
.. autosummary::
   :toctree: generated/

   read_gpickle
   write_gpickle
