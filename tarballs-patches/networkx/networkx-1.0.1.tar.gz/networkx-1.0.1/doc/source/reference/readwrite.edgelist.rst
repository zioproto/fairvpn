
Edge List
=========
.. automodule:: networkx.readwrite.edgelist
.. currentmodule:: networkx
.. autosummary::
   :toctree: generated/

   read_edgelist
   write_edgelist
