*********
Bipartite
*********

.. automodule:: networkx.algorithms.bipartite

.. currentmodule:: networkx
.. autosummary::
   :toctree: generated/

   is_bipartite
   bipartite_sets
   bipartite_color
   project
