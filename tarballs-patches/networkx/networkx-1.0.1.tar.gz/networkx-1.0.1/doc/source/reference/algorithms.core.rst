*****
Cores
*****

.. automodule:: networkx.algorithms.core
.. currentmodule:: networkx
.. autosummary::
   :toctree: generated/

   find_cores
