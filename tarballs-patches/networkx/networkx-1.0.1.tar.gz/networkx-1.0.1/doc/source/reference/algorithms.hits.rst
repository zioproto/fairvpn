****
HITS
****

.. automodule:: networkx.algorithms.hits
.. currentmodule:: networkx
.. autosummary::
   :toctree: generated/

   hits
   hits_numpy
   hits_scipy
   hub_matrix
   authority_matrix


