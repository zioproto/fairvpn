********
Boundary
********

.. automodule:: networkx.algorithms.boundary
.. currentmodule:: networkx
.. autosummary::
   :toctree: generated/

   edge_boundary
   node_boundary

