.. _readwrite:

**************************
Reading and writing graphs
**************************

.. toctree::
   :maxdepth: 2

   readwrite.adjlist
   readwrite.edgelist
   readwrite.gml
   readwrite.gpickle
   readwrite.graphml
   readwrite.leda
   readwrite.yaml
   readwrite.sparsegraph6
   readwrite.pajek
