LEDA
====
.. automodule:: networkx.readwrite.leda
.. currentmodule:: networkx
.. autosummary::
   :toctree: generated/

   read_leda
   parse_leda



