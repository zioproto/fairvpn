********
PageRank
********

.. automodule:: networkx.algorithms.pagerank
.. currentmodule:: networkx
.. autosummary::
   :toctree: generated/

   pagerank
   pagerank_numpy
   pagerank_scipy
   google_matrix


