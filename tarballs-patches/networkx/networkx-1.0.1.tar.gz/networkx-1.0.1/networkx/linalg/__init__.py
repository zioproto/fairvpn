
# need numpy for spectrum
try:
    from spectrum import *
except ImportError:
    pass
